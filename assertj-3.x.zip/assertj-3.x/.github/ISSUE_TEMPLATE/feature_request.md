---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

#### Feature summary


#### Example

```java
<add example here>
```
